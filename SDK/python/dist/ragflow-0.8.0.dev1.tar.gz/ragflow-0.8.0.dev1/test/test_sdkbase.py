class TestSdk():
    def test_version(self):
        print("test_sdk")
